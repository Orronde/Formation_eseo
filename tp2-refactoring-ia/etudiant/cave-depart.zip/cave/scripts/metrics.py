#!/usr/bin/env python3
"""Mesures de qualité du code de src/main/java (hors tests).

Approximatif mais stable : deux versions d'un même code sont comparables.
Bibliothèque standard uniquement (Python 3.9+).

Usage :
  python3 scripts/metrics.py                 tableau lisible
  python3 scripts/metrics.py --csv           une ligne CSV (sans en-tête)
  python3 scripts/metrics.py --csv-header    l'en-tête du CSV
  python3 scripts/metrics.py autre/dossier   analyser un autre dossier source

Définitions :
  - lignes utiles      : lignes ni vides ni réduites à un commentaire
  - méthode            : méthode ou constructeur, découpé par appariement d'accolades
  - longueur           : lignes physiques de la signature à l'accolade fermante
  - imbrication        : blocs if/else/for/while/do/switch/try/catch emboîtés
                         dans une méthode (0 = aucun)
  - complexité         : 1 + nombre de if, for, while, case, catch, &&, ||, ?
  - nombre magique     : littéral entier autre que 0, 1, -1, hors déclaration
                         de constante (static final, ou nom en MAJUSCULES) et
                         hors lignes « new Bottle(...) » (données de simulation)
  - comparaison de nom : equals / startsWith avec un littéral de chaîne
"""
import re
import sys
from pathlib import Path

CONTROL = {"if", "else", "for", "while", "do", "switch", "try", "catch", "finally"}
NOT_METHOD = CONTROL | {"synchronized", "new", "return", "throw", "assert"}
TYPE_RE = re.compile(
    r"(?:^|[\s;{}])(?:(?:public|private|protected|static|final|abstract|sealed|non-sealed|strictfp)\s+)*"
    r"(class|interface|enum|record)\s+([A-Za-z_]\w*)")
SIG_RE = re.compile(
    r"([A-Za-z_]\w*)\s*\((?:[^()]|\([^()]*\))*\)\s*(?:throws\s+[\w.,\s]+)?\s*$", re.S)
CONST_RE = re.compile(r"^\s*(?:(?:public|private|protected|static|final)\s+)*[\w<>\[\],.? ]+\s+[A-Z][A-Z0-9_]*\s*=")
EQ_RE = re.compile(r'(?:\.\s*(?:equals|startsWith|equalsIgnoreCase)\s*\(\s*"[^"\n]*")|(?:"[^"\n]*"\s*\.\s*(?:equals|startsWith|equalsIgnoreCase)\s*\()')


def strip_comments(src):
    """Supprime les commentaires en gardant les sauts de ligne et les chaînes."""
    out, i, n = [], 0, len(src)
    while i < n:
        c = src[i]
        if c == '"' or c == "'":
            j = i + 1
            while j < n and src[j] != c:
                j += 2 if src[j] == "\\" else 1
            out.append(src[i:j + 1])
            i = j + 1
        elif src.startswith("//", i):
            while i < n and src[i] != "\n":
                i += 1
        elif src.startswith("/*", i):
            j = src.find("*/", i + 2)
            j = n if j < 0 else j + 2
            out.append("\n" * src.count("\n", i, j))
            i = j
        else:
            out.append(c)
            i += 1
    return "".join(out)


def blank_strings(src):
    """Remplace le contenu des chaînes et caractères par du vide."""
    def repl(m):
        return m.group(0)[0] + m.group(0)[-1]
    return re.sub(r'"(?:\\.|[^"\\\n])*"|\'(?:\\.|[^\'\\\n])*\'', repl, src)


def analyse_file(path):
    raw = path.read_text(encoding="utf-8")
    code = strip_comments(raw)
    flat = blank_strings(code)
    lines = flat.split("\n")
    useful = sum(1 for l in lines if l.strip())

    # Types déclarés
    types = len(TYPE_RE.findall(flat))

    # Parcours des accolades
    stack = []          # éléments : (kind, start_line, name, ctrl_depth)
    methods = []
    last_cut = 0
    line = 1
    for idx, ch in enumerate(flat):
        if ch == "\n":
            line += 1
        elif ch == "{":
            head = flat[last_cut:idx]
            tail = head.split(";")[-1]
            kind, name = "other", None
            top = stack[-1][0] if stack else None
            if TYPE_RE.search(" " + tail) and "(" not in tail.split("class")[0] + tail.split("record")[0][:0]:
                kind = "type"
            elif top == "type":
                m = SIG_RE.search(tail.strip())
                if m and m.group(1) not in NOT_METHOD and "=" not in tail:
                    kind, name = "method", m.group(1)
            elif top in ("method", "ctrl", "other"):
                words = re.findall(r"[A-Za-z_]+", tail.strip().split("(")[0])
                first = words[-1] if words else ""
                if first in CONTROL or re.match(r"\s*\}?\s*else\b", tail) or tail.strip() == "":
                    kind = "ctrl"
            stack.append((kind, line, name, idx))
            last_cut = idx + 1
        elif ch == "}":
            if stack:
                kind, start, name, open_idx = stack.pop()
                if kind == "method":
                    # ligne de la signature : première ligne de l'en-tête
                    head_start = flat.rfind("\n", 0, open_idx)
                    sig_line = flat.count("\n", 0, open_idx) + 1
                    body = flat[open_idx:idx + 1]
                    methods.append(measure_method(name, sig_line, line, body))
            last_cut = idx + 1
        elif ch == ";":
            last_cut = idx + 1
    return {"useful": useful, "types": types, "methods": methods, "flat": flat,
            "code": code, "const_free": const_free_numbers(flat)}


def measure_method(name, start, end, body):
    # imbrication : accolades de blocs de contrôle emboîtées
    depth = best = 0
    stack = []
    last = 0
    paren = 0
    for idx, ch in enumerate(body):
        if idx == 0:
            continue
        if ch == "(":
            paren += 1
        elif ch == ")":
            paren -= 1
        if ch == "{":
            head = body[last:idx].strip()
            is_ctrl = bool(re.match(r"(?:\}\s*)?(?:else\b|if\b|for\b|while\b|do\b|switch\b|try\b|catch\b|finally\b)", head)) \
                or bool(re.search(r"\b(?:if|for|while|switch|catch)\s*\(.*\)\s*$", head, re.S)) \
                or head in ("else", "do", "try", "finally")
            stack.append(is_ctrl)
            if is_ctrl:
                depth += 1
                best = max(best, depth)
            last = idx + 1
        elif ch == "}":
            if stack and stack.pop():
                depth -= 1
            last = idx + 1
        elif ch == ";" and paren == 0:
            last = idx + 1
    cyclo = 1 + len(re.findall(r"\b(?:if|for|while|case|catch)\b", body)) \
        + body.count("&&") + body.count("||") + body.count("?")
    return {"name": name, "length": end - start + 1, "nesting": best, "cyclo": cyclo}


def const_free_numbers(flat):
    count = 0
    for l in flat.split("\n"):
        if CONST_RE.match(l) or "new Bottle(" in l:
            continue
        count += len([x for x in re.findall(r"(?<![\w.])\d+(?![\w.])", l) if x not in ("0", "1")])
    return count


def analyse(root):
    files = sorted(Path(root).rglob("*.java"))
    res = {"files": len(files), "useful": 0, "types": 0, "magic": 0, "cmp": 0, "methods": []}
    for f in files:
        a = analyse_file(f)
        res["useful"] += a["useful"]
        res["types"] += a["types"]
        res["magic"] += a["const_free"]
        res["cmp"] += len(EQ_RE.findall(a["code"]))
        for m in a["methods"]:
            m["file"] = f.name
            res["methods"].append(m)
    ms = res["methods"]
    worst = max(ms, key=lambda m: (m["cyclo"], m["length"])) if ms else None
    res["max_length"] = max((m["length"] for m in ms), default=0)
    res["max_nesting"] = max((m["nesting"] for m in ms), default=0)
    res["max_cyclo"] = max((m["cyclo"] for m in ms), default=0)
    res["worst"] = f'{worst["file"]}:{worst["name"]}' if worst else "-"
    return res


CSV_FIELDS = ["lignes_utiles", "fichiers", "classes", "methode_max_lignes",
              "imbrication_max", "complexite_max", "nombres_magiques", "comparaisons_noms"]


def main(argv):
    args = [a for a in argv if not a.startswith("--")]
    here = Path(__file__).resolve().parent.parent
    root = Path(args[0]) if args else here / "src" / "main" / "java"
    if "--csv-header" in argv:
        print(",".join(CSV_FIELDS))
        return 0
    if not root.exists():
        print(f"Dossier introuvable : {root}", file=sys.stderr)
        return 2
    r = analyse(root)
    values = [r["useful"], r["files"], r["types"], r["max_length"], r["max_nesting"],
              r["max_cyclo"], r["magic"], r["cmp"]]
    if "--csv" in argv:
        print(",".join(str(v) for v in values))
        return 0
    print(f"Analyse de {root}")
    print(f"  Lignes de code utiles ........ {r['useful']}")
    print(f"  Fichiers ..................... {r['files']}")
    print(f"  Classes/interfaces/enums ..... {r['types']}")
    print(f"  Méthode la plus longue ....... {r['max_length']} lignes")
    print(f"  Imbrication maximale ......... {r['max_nesting']}")
    print(f"  Complexité cyclomatique max .. {r['max_cyclo']}   (pire méthode : {r['worst']})")
    print(f"  Nombres magiques ............. {r['magic']}")
    print(f"  Comparaisons de noms ......... {r['cmp']}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
