#!/usr/bin/env bash
# Vérifie votre travail en cinq contrôles.
#
#   scripts/verifier.sh            comportement = celui du départ (phases 3 et 4)
#   scripts/verifier.sh refacto    idem
#   scripts/verifier.sh r1         comportement du départ + évolution R1 (phases 1 et 5)
#   scripts/verifier.sh r2         R1 + R2 (bonus)
#
# Code de sortie : 0 si tout est au vert, 1 sinon.
MODE="${1:-refacto}"
case "$MODE" in refacto|r1|r2) ;; *) echo "Mode inconnu : $MODE (refacto, r1 ou r2)"; exit 2 ;; esac

RACINE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$RACINE" || exit 2
LOG="$(mktemp -d)"
trap 'rm -rf "$LOG"' EXIT

# Séparateur de classpath et forme du chemin selon le système
SEP=":"
case "$(uname -s)" in MINGW*|MSYS*|CYGWIN*) SEP=";" ;; esac

# Vérificateur de comportement (jar distribué à côté du projet)
JAR=""
for c in "${GOLDEN_JAR:-}" "$RACINE/../outils/golden-check.jar" "$RACINE/../../outils/golden-check.jar" "$RACINE/../../../outils/golden-check.jar" "$RACINE/outils/golden-check.jar"; do
  if [ -n "$c" ] && [ -f "$c" ]; then JAR="$c"; break; fi
done
if [ -z "$JAR" ]; then
  echo "golden-check.jar introuvable (attendu dans ../outils/). Dézippez bien tout le dossier fourni."
  exit 2
fi
JARP="$JAR"
if command -v cygpath >/dev/null 2>&1; then JARP="$(cygpath -w "$JAR")"; fi

JAVA_OPTS="-Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8"
OK_ALL=1
R_COMPIL=""; R_COMPORT=""; R_BOTTLE=""; R_TESTS=""

# --- 1. Compilation ---------------------------------------------------------
if command -v mvn >/dev/null 2>&1 && [ -z "${CAVE_SANS_MAVEN:-}" ]; then
  if mvn -q compile >"$LOG/compile.txt" 2>&1; then R_COMPIL="OK"; else R_COMPIL="ÉCHEC"; OK_ALL=0; fi
else
  # Repli sans Maven : compilation directe avec javac
  mkdir -p target/classes
  find src/main/java -name '*.java' >"$LOG/sources.txt"
  if javac --release 17 -encoding UTF-8 -d target/classes @"$LOG/sources.txt" >"$LOG/compile.txt" 2>&1; then
    R_COMPIL="OK (javac, Maven absent)"
  else
    R_COMPIL="ÉCHEC"; OK_ALL=0
  fi
fi

# --- 2. Comportement --------------------------------------------------------
if [ "$R_COMPIL" = "ÉCHEC" ]; then
  R_COMPORT="non vérifié (compilation en échec)"
else
  java $JAVA_OPTS -cp "target/classes${SEP}${JARP}" fr.cavemanager.check.Main --mode "$MODE" >"$LOG/golden-brut.txt" 2>&1
  CODE=$?
  grep -v '^Picked up' "$LOG/golden-brut.txt" >"$LOG/golden.txt"
  case $CODE in
    0) R_COMPORT="OK — $(head -n 1 "$LOG/golden.txt" | sed 's/^OK : //')" ;;
    1) R_COMPORT="DIFFÉRENT — $(head -n 1 "$LOG/golden.txt")"; OK_ALL=0 ;;
    *) R_COMPORT="NON VÉRIFIABLE — $(head -n 1 "$LOG/golden.txt")"; OK_ALL=0 ;;
  esac
fi

# --- 3. Bottle.java ---------------------------------------------------------
BOTTLE="src/main/java/fr/cavemanager/Bottle.java"
REF=".depart/$BOTTLE"
if [ ! -f "$REF" ]; then
  R_BOTTLE="non vérifiable (dossier .depart/ introuvable)"; OK_ALL=0
elif cmp -s <(tr -d '\r' <"$BOTTLE") <(tr -d '\r' <"$REF"); then
  R_BOTTLE="intact"
else
  R_BOTTLE="MODIFIÉ — cette classe appartient à une autre équipe, ne la touchez pas"; OK_ALL=0
fi

# --- 4. Tests ---------------------------------------------------------------
if command -v mvn >/dev/null 2>&1 && [ -z "${CAVE_SANS_MAVEN:-}" ]; then
  if mvn -q test >"$LOG/test.txt" 2>&1; then
    N=0
    for f in target/surefire-reports/TEST-*.xml; do
      [ -f "$f" ] || continue
      T="$(sed -n 's/.*<testsuite [^>]*tests="\([0-9]*\)".*/\1/p' "$f" | head -n 1)"
      N=$((N + ${T:-0}))
    done
    R_TESTS="$N test(s), tous au vert"
  else
    R_TESTS="ÉCHEC (voir ci-dessous)"; OK_ALL=0
  fi
else
  R_TESTS="non exécutés (Maven absent)"
fi

# --- Résumé en cinq lignes --------------------------------------------------
if [ $OK_ALL -eq 1 ]; then VERDICT="TOUT EST AU VERT"; else VERDICT="À CORRIGER"; fi
echo "1. Compilation .............. $R_COMPIL"
echo "2. Comportement (mode $MODE) .. $R_COMPORT"
echo "3. Bottle.java .............. $R_BOTTLE"
echo "4. Tests .................... $R_TESTS"
echo "5. Verdict .................. $VERDICT"

# --- Détails en cas de problème --------------------------------------------
if [ "$R_COMPIL" = "ÉCHEC" ]; then
  echo; echo "--- Erreurs de compilation ---"; tail -n 20 "$LOG/compile.txt"
fi
if [ -f "$LOG/golden.txt" ] && [ "$(wc -l <"$LOG/golden.txt")" -gt 1 ]; then
  echo; echo "--- Détail du comportement ---"; cat "$LOG/golden.txt"
fi
if [ "$R_TESTS" = "ÉCHEC (voir ci-dessous)" ]; then
  echo; echo "--- Tests en échec ---"; grep -E "ERROR|FAIL|Tests run" "$LOG/test.txt" | head -n 20
fi
[ $OK_ALL -eq 1 ]
