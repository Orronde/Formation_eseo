#!/usr/bin/env bash
# Lance VOS tests sur le code de départ (dossier .depart/).
# Le code de départ fait foi : un test qui échoue ici affirme quelque chose de faux.
#
#   scripts/tests-sur-depart.sh
#
# Code de sortie : 0 si aucun test n'échoue sur le départ, 1 sinon, 2 si le contrôle est impossible.
RACINE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$RACINE" || exit 2

if [ ! -f .depart/pom.xml ] || [ ! -d .depart/src/main ]; then
  echo "Dossier .depart/ introuvable : impossible de reconstituer le code de départ."; exit 2
fi
if ! command -v mvn >/dev/null 2>&1; then
  echo "Maven est nécessaire pour lancer les tests."; exit 2
fi
if [ -z "$(find src/test -name '*.java' 2>/dev/null | head -n 1)" ]; then
  echo "Aucun test trouvé dans src/test/java."; exit 2
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cp .depart/pom.xml "$TMP/pom.xml"
mkdir -p "$TMP/src"
cp -R .depart/src/main "$TMP/src/main"
cp -R src/test "$TMP/src/test"

( cd "$TMP" && mvn -q test ) >"$TMP/sortie.txt" 2>&1
CODE=$?

if [ $CODE -eq 0 ]; then
  N=0
  for f in "$TMP"/target/surefire-reports/TEST-*.xml; do
    [ -f "$f" ] || continue
    T="$(sed -n 's/.*<testsuite [^>]*tests="\([0-9]*\)".*/\1/p' "$f" | head -n 1)"
    N=$((N + ${T:-0}))
  done
  echo "OK : $N test(s) passent sur le code de départ. Aucun test ne contredit le comportement d'origine."
  exit 0
fi

if grep -q "COMPILATION ERROR" "$TMP/sortie.txt"; then
  echo "Vos tests ne compilent pas sur le code de départ : ils utilisent sans doute des classes ou des"
  echo "méthodes qui n'existent qu'après votre refactoring. Un bon test de comportement passe par"
  echo "l'API publique (Bottle, Cellar.ageOneMonth) et fonctionne sur les deux versions."
  grep -E "ERROR.*\.java" "$TMP/sortie.txt" | head -n 8
  exit 1
fi

echo "ÉCHEC : des tests ne passent pas sur le code de départ."
echo "Chacun encode une hypothèse que le code d'origine ne respecte pas :"
grep -hE "<<< (FAILURE|ERROR)!" "$TMP"/target/surefire-reports/*.txt 2>/dev/null | sed 's/ -- Time elapsed.*//' | sort -u | head -n 30
exit 1
