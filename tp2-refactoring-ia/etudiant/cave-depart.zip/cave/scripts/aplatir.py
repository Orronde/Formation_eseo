#!/usr/bin/env python3
"""Produit un fichier texte unique pour un chat sans accès aux fichiers.

Contenu : docs/REGLES.md, puis chaque fichier de src/main/java, introduits par
une ligne « === chemin === », chaque ligne de code préfixée de son numéro
(« 012 | ... »). À coller en début de conversation ; à régénérer après chaque phase.

Usage :
  python3 scripts/aplatir.py                  écrit cave-aplati.txt à la racine du projet
  python3 scripts/aplatir.py -o autre.txt     choisit le fichier de sortie
  python3 scripts/aplatir.py --stdout         écrit sur la sortie standard

Bibliothèque standard uniquement (Python 3.9+).
"""
import argparse
import sys
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent
TOKENS_MAX = 4000


def aplatir(racine):
    parties = []
    regles = racine / "docs" / "REGLES.md"
    if regles.exists():
        parties.append("=== docs/REGLES.md ===\n" + regles.read_text(encoding="utf-8").rstrip() + "\n")
    for fichier in sorted((racine / "src" / "main" / "java").rglob("*.java")):
        chemin = fichier.relative_to(racine).as_posix()
        lignes = fichier.read_text(encoding="utf-8").rstrip("\n").split("\n")
        largeur = max(3, len(str(len(lignes))))
        corps = "\n".join(f"{i:0{largeur}d} | {l}" for i, l in enumerate(lignes, 1))
        parties.append(f"=== {chemin} ===\n{corps}\n")
    return "\n".join(parties)


def estimer_tokens(texte):
    # Estimation prudente : ~3 caractères par token pour du code et du français accentué
    return len(texte) // 3 + 1


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("-o", "--output", default=str(RACINE / "cave-aplati.txt"))
    p.add_argument("--stdout", action="store_true")
    a = p.parse_args()
    texte = aplatir(RACINE)
    if a.stdout:
        sys.stdout.write(texte)
        return 0
    Path(a.output).write_text(texte, encoding="utf-8")
    n = estimer_tokens(texte)
    print(f"{a.output} : {len(texte.splitlines())} lignes, environ {n} tokens", file=sys.stderr)
    if n > TOKENS_MAX:
        print(f"Attention : au-dessus de {TOKENS_MAX} tokens, certains chats gratuits le tronqueront.", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
