#!/usr/bin/env python3
"""Suivi de votre travail, sauvegardes de phase, retour en arrière et mesure du diff.

Le code de départ est conservé dans `.depart/` (ne le modifiez pas, ne le donnez pas à l'IA).
Vos sauvegardes de phase sont dans `.suivi/`.

Commandes (depuis le dossier du projet) :
  python3 scripts/suivi.py sauvegarder 1        sauvegarde l'état actuel comme « phase 1 » (1 à 5)
  python3 scripts/suivi.py restaurer depart     remet le code de départ (phase 3)
  python3 scripts/suivi.py restaurer 4          remet l'état sauvegardé à la fin de la phase 4 (phase 5)
  python3 scripts/suivi.py fichier Cellar.java  remet UN fichier à son état de départ
  python3 scripts/suivi.py diff depart 1        taille de votre modification entre le départ et la phase 1
  python3 scripts/suivi.py diff 4 5             idem entre la phase 4 et la phase 5
  python3 scripts/suivi.py diff depart          idem entre le départ et l'état actuel
  python3 scripts/suivi.py liste                sauvegardes disponibles

`restaurer` garde d'abord une copie de l'état actuel dans `.suivi/avant-restauration-<date>/` : rien n'est perdu.
Bibliothèque standard uniquement (Python 3.9+).
"""
import difflib
import re
import shutil
import sys
import time
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent
DEPART = RACINE / ".depart"
SUIVI = RACINE / ".suivi"
SOURCES = "src"
EXTRAS = ["AGENTS.md"]
PHASES = ["1", "2", "3", "4", "5"]
TYPE_RE = re.compile(r"(?:^|[\s;{}])(?:(?:public|private|protected|static|final|abstract|sealed)\s+)*(class|interface|enum|record)\s+[A-Za-z_]\w*")


def lire(path):
    return path.read_text(encoding="utf-8", errors="replace").replace("\r\n", "\n").split("\n")


def etat(nom):
    """Dossier contenant l'état désigné : « depart », « 1 » à « 5 » ou « courant »."""
    if nom == "depart":
        return DEPART
    if nom == "courant":
        return RACINE
    n = nom.replace("phase", "")
    if n in PHASES:
        return SUIVI / f"phase{n}"
    sys.exit(f"État inconnu : {nom} (attendu : depart, 1 à 5, courant)")


def fichiers(base):
    src = base / SOURCES
    if not src.exists():
        return {}
    return {p.relative_to(base).as_posix(): p for p in sorted(src.rglob("*"))
            if p.is_file() and p.name != ".keep"}


def copier(source, dest):
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True)
    if (source / SOURCES).exists():
        shutil.copytree(source / SOURCES, dest / SOURCES)
    for extra in EXTRAS:
        if (source / extra).exists():
            shutil.copy2(source / extra, dest / extra)


def sauvegarder(n):
    if n not in PHASES:
        sys.exit("Numéro de phase attendu : 1 à 5")
    cible = SUIVI / f"phase{n}"
    copier(RACINE, cible)
    print(f"Phase {n} sauvegardée : {len(fichiers(cible))} fichier(s) sous src/ (+ AGENTS.md s'il existe).")


def restaurer(nom):
    source = etat(nom)
    if not source.exists():
        sys.exit(f"Rien à restaurer pour « {nom} » (sauvegarde absente).")
    horodatage = time.strftime("%Y%m%d-%H%M%S")
    copier(RACINE, SUIVI / f"avant-restauration-{horodatage}")
    shutil.rmtree(RACINE / SOURCES, ignore_errors=True)
    shutil.copytree(source / SOURCES, RACINE / SOURCES)
    if nom != "depart":  # au départ, on garde vos guidelines
        for extra in EXTRAS:
            if (source / extra).exists():
                shutil.copy2(source / extra, RACINE / extra)
    (RACINE / "src" / "test" / "java").mkdir(parents=True, exist_ok=True)
    print(f"État « {nom} » restauré. Copie de votre état précédent : .suivi/avant-restauration-{horodatage}/")


def fichier(nom):
    candidats = [p for k, p in fichiers(DEPART).items() if k.endswith("/" + nom) or k == nom]
    if len(candidats) != 1:
        sys.exit(f"« {nom} » : {len(candidats)} correspondance(s) dans le code de départ. Donnez un nom exact (ex. Cellar.java).")
    rel = candidats[0].relative_to(DEPART)
    cible = RACINE / rel
    cible.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(candidats[0], cible)
    print(f"{rel.as_posix()} remis à son état de départ.")


def types(path):
    return len(TYPE_RE.findall("\n".join(lire(path))))


def diff(a, b):
    ba, bb = etat(a), etat(b)
    for nom, base in ((a, ba), (b, bb)):
        if not base.exists():
            sys.exit(f"« {nom} » : pas de sauvegarde (python3 scripts/suivi.py sauvegarder N).")
    fa, fb = fichiers(ba), fichiers(bb)
    ajoutees = supprimees = 0
    touches = []
    for rel in sorted(set(fa) | set(fb)):
        la = lire(fa[rel]) if rel in fa else []
        lb = lire(fb[rel]) if rel in fb else []
        if la == lb:
            continue
        plus = moins = 0
        for ligne in difflib.unified_diff(la, lb, lineterm="", n=0):
            if ligne.startswith("+") and not ligne.startswith("+++"):
                plus += 1
            elif ligne.startswith("-") and not ligne.startswith("---"):
                moins += 1
        ajoutees += plus
        supprimees += moins
        touches.append((rel, plus, moins, rel not in fa, rel not in fb))
    main = [t for t in touches if "/main/" in t[0]]
    hors = [t for t in touches if not t[0].endswith("/Cellar.java")]
    classes = sum(types(fb[r]) for r in fb if "/main/" in r and r.endswith(".java")) \
        - sum(types(fa[r]) for r in fa if "/main/" in r and r.endswith(".java"))
    print(f"Diff {a} -> {b}")
    print(f"  Fichiers touchés ........................ {len(touches)}")
    print(f"  Lignes ajoutées / supprimées ............ +{ajoutees} / -{supprimees}  (total {ajoutees + supprimees})")
    print(f"  dont code (src/main) .................... +{sum(t[1] for t in main)} / -{sum(t[2] for t in main)}")
    print(f"  Fichiers touchés hors Cellar.java ....... {len(hors)}")
    print(f"  Classes créées (src/main) ............... {max(classes, 0)}")
    bottle = [t for t in touches if t[0].endswith("/Bottle.java")]
    if bottle:
        print("  ATTENTION : Bottle.java est modifié (cette classe appartient à une autre équipe).")
    for rel, plus, moins, nouveau, supprime in touches:
        marque = "nouveau" if nouveau else ("supprimé" if supprime else "modifié")
        print(f"    {marque:9s} {rel}  (+{plus} / -{moins})")


def liste():
    print("Code de départ :", "présent" if DEPART.exists() else "ABSENT (.depart/)")
    if not SUIVI.exists():
        print("Aucune sauvegarde.")
        return
    for d in sorted(SUIVI.iterdir()):
        if d.is_dir():
            print(f"  {d.name:35s} {len(fichiers(d))} fichier(s)")


def main(argv):
    if not argv or argv[0] in ("-h", "--aide", "--help"):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]
    if cmd == "sauvegarder" and len(args) == 1:
        sauvegarder(args[0].replace("phase", ""))
    elif cmd == "restaurer" and len(args) == 1:
        restaurer(args[0])
    elif cmd == "fichier" and len(args) == 1:
        fichier(args[0])
    elif cmd == "diff" and len(args) in (1, 2):
        diff(args[0], args[1] if len(args) == 2 else "courant")
    elif cmd == "liste":
        liste()
    else:
        print(__doc__)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
