# CaveManager

CaveManager gère les bouteilles d'une cave à vins. Chaque mois, `Cellar.ageOneMonth()` met à jour
l'échéance (`monthsLeft`) et la cote (`rating`) de toutes les bouteilles. Les règles sont décrites dans
[`docs/REGLES.md`](docs/REGLES.md).

```text
src/main/java/fr/cavemanager/
  Bottle.java   une bouteille : name, monthsLeft, rating (champs publics)
  Cellar.java   la cave : Bottle[] bottles et ageOneMonth()
  Main.java     simule N mois et affiche la cave (N = premier argument, 10 par défaut)
src/test/java/  vide au départ
docs/REGLES.md  spécification métier
scripts/        verifier, tests-sur-depart, metrics, aplatir
```

## Règles du projet

- **`Bottle.java` appartient à une autre équipe : vous ne devez pas le modifier.**
- L'API publique reste celle du départ : package `fr.cavemanager`, classes `Bottle`, `Cellar` et `Main`,
  constructeurs `Bottle(String, int, int)` et `Cellar(Bottle[])`, méthode `ageOneMonth()`, champs publics de `Bottle`.
  Vous pouvez ajouter des classes dans ce package ou dans un sous-package.
- Aucune dépendance à ajouter au `pom.xml` (sauf JUnit 5 pour les tests, déjà présent).
- Le code de départ fait foi : si un détail du comportement vous surprend, ne le « corrigez » pas, notez-le.

## Prérequis

JDK 17 ou plus, Maven 3.8 ou plus, Python 3.9 ou plus. La première commande Maven télécharge les
dépendances : prévoyez du réseau. Dézippez `cave-depart.zip` en entier : le dossier `outils/` (qui contient
`golden-check.jar`) doit rester à côté de `cave/`.

## Commandes

Terminal bash (macOS, Linux, ou Windows avec un terminal bash), depuis le dossier `cave/` :

```bash
mvn -q compile                       # compiler
mvn -q test                          # lancer les tests (JUnit 5)
mvn -q verify                        # tests + couverture : target/site/jacoco/index.html
java -cp target/classes fr.cavemanager.Main 12      # lancer la simulation sur 12 mois
scripts/verifier.sh refacto          # cinq contrôles ; modes : refacto, r1, r2
scripts/tests-sur-depart.sh          # vos tests, exécutés sur le code de départ
python3 scripts/metrics.py           # mesures de qualité (ajouter --csv pour une ligne CSV)
python3 scripts/aplatir.py           # cave-aplati.txt pour un chat sans accès aux fichiers
python3 scripts/suivi.py liste       # sauvegardes de phase (voir « Sauvegardes de phase » plus bas)
```

### `scripts/verifier.sh` : arguments

```bash
scripts/verifier.sh [mode]
```

| Mode | Ce qui est vérifié | Quand l'utiliser |
| --- | --- | --- |
| `refacto` (défaut) | le comportement est **identique à celui du départ** | phases 3 et 4 (refactoring, tests) |
| `r1` | comportement du départ **plus l'évolution R1** (« Entamé ») | phases 1 et 5 |
| `r2` | R1 **plus** R2 (« Bio ») | bonus, si votre fiche vous le demande |

Sans argument, le mode est `refacto`. Un mode inconnu arrête le script avec le code 2. Le script enchaîne cinq contrôles :
compilation, comportement, `Bottle.java` inchangé, tests (`mvn -q test`), verdict.

| Code de sortie | Sens |
| --- | --- |
| 0 | tout est au vert |
| 1 | au moins un contrôle échoue : lisez le détail affiché sous le résumé (une API devenue incompatible s'affiche « NON VÉRIFIABLE ») |
| 2 | le script ne peut pas démarrer : mode inconnu, ou `golden-check.jar` introuvable (il doit se trouver dans `../outils/`) |

Variante sans Maven : `CAVE_SANS_MAVEN=1 scripts/verifier.sh r1` compile avec `javac` et ne lance pas les tests JUnit.

Invite de commandes Windows (`cmd`), depuis le dossier `cave\` :

```bat
mvn -q compile
mvn -q test
java -Dfile.encoding=UTF-8 -cp target\classes fr.cavemanager.Main 12
java -Dfile.encoding=UTF-8 -cp "target\classes;..\outils\golden-check.jar" fr.cavemanager.check.Main --mode refacto
fc src\main\java\fr\cavemanager\Bottle.java .depart\src\main\java\fr\cavemanager\Bottle.java
python scripts\metrics.py
python scripts\aplatir.py
```

Pour lancer vos tests sur le code de départ sans bash (le dossier `.depart\` contient le code d'origine) :

```bat
rmdir /s /q ..\cave-depart-test 2>nul
xcopy /E /I /Y .depart ..\cave-depart-test
xcopy /E /I /Y src\test ..\cave-depart-test\src\test
cd ..\cave-depart-test
mvn -q test
cd ..\cave
```

Les accents s'affichent mal dans `cmd` : tapez `chcp 65001` avant, ou utilisez PowerShell.

## Sauvegardes de phase

Rien n'est envoyé ni publié : `scripts/suivi.py` fait des copies locales de `src/` (et de votre `AGENTS.md`) dans `.suivi/`,
et garde le code d'origine dans `.depart/` (ne le modifiez pas, ne le donnez pas à l'IA).

```bash
python3 scripts/suivi.py sauvegarder 1      # à la fin de chaque phase (1 à 5)
python3 scripts/suivi.py diff depart 1      # taille de la modification : départ -> phase 1
python3 scripts/suivi.py diff 4 5           # idem entre les phases 4 et 5
python3 scripts/suivi.py restaurer depart   # revient au code d'origine (début de la phase 3)
python3 scripts/suivi.py restaurer 4        # revient à la fin de la phase 4 (début de la phase 5)
python3 scripts/suivi.py fichier Cellar.java  # remet un seul fichier à son état d'origine
python3 scripts/suivi.py liste              # sauvegardes disponibles
```

`restaurer` conserve d'abord une copie de votre état actuel dans `.suivi/avant-restauration-<date>/` : rien n'est perdu.
Le diff indique les fichiers touchés, les lignes ajoutées et supprimées, les fichiers touchés hors `Cellar.java` et les classes créées.
