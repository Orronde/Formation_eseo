# Règles de mise à jour de la cave (CaveManager)

Chaque mois, `Cellar.ageOneMonth()` met à jour chaque bouteille.
Une bouteille a un nom, un nombre de mois restants (`monthsLeft`) et une cote (`rating`).

## Règles générales
- Chaque mois, `monthsLeft` diminue de 1, sauf pour la Cuvée du Fondateur.
- Une fois l'échéance dépassée (`monthsLeft` négatif après la mise à jour), la cote évolue deux fois plus vite.
- La cote d'une bouteille normale ne devient jamais négative du fait de la mise à jour.
- La cote d'une bouteille ne dépasse jamais 60 du fait de la mise à jour.

## Bouteilles normales
- La cote diminue de 1 par mois, de 2 une fois l'échéance dépassée.

## Pomerol de garde (nom exact)
- La cote augmente de 1 par mois, de 2 une fois l'échéance dépassée.

## Cuvée du Fondateur (nom exact)
- Ne périme jamais et ne perd jamais de cote : ni `monthsLeft` ni `rating` ne changent.
- Sa cote vaut 100.

## Primeur (nom commençant par « Primeur »)
- La cote augmente de 1 par mois quand il reste plus de 14 mois avant la mise à jour.
- Elle augmente de 2 par mois quand il reste de 8 à 14 mois.
- Elle augmente de 3 par mois quand il reste 7 mois ou moins.
- Une fois la livraison passée (`monthsLeft` négatif après la mise à jour), la cote tombe à 0.
