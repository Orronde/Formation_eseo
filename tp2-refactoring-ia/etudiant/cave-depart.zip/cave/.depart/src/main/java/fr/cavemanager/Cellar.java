package fr.cavemanager;

public class Cellar {
    public Bottle[] bottles;

    public Cellar(Bottle[] bottles) {
        this.bottles = bottles;
    }

    public void ageOneMonth() {
        for (int i = 0; i < bottles.length; i++) {
            Bottle it = bottles[i];
            String n = it.name;
            int m = it.monthsLeft;

            if (n.equals("Pomerol de garde")) {
                if (it.rating < 60) {
                    it.rating = it.rating + 1;
                }
            } else if (n.startsWith("Primeur")) {
                // cote max : 50
                if (m > 14 && it.rating < 60) {
                    it.rating = Math.min(60, it.rating + 1);
                }
                if (m > 7 && m < 15) {
                    if (it.rating < 60) {
                        it.rating = Math.min(60, it.rating + 2);
                    }
                }
                if (m < 8) {
                    if (it.rating < 60) {
                        it.rating = Math.min(60, it.rating + 3);
                    }
                }
            } else {
                if (!n.equals("Cuvée du Fondateur")) {
                    if (it.rating > 0) {
                        it.rating = it.rating - 1;
                    }
                }
            }

            // TODO supprimer, plus utilisé
            if (!n.equals("Cuvée du Fondateur")) {
                it.monthsLeft = m - 1;
            }

            if (it.monthsLeft < 0) {
                if (!n.equals("Pomerol de garde") && !n.startsWith("Primeur")) {
                    if (!n.equals("Cuvée du Fondateur")) {
                        if (it.rating > 0) {
                            it.rating = it.rating - 1;
                        }
                    }
                } else {
                    if (n.startsWith("Primeur")) {
                        it.rating = 0;
                    } else {
                        if (it.rating < 60) {
                            it.rating = it.rating + 1;
                        }
                    }
                }
            }
        }
    }
}
