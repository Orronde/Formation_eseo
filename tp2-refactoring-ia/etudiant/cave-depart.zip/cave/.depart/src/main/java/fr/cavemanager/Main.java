package fr.cavemanager;

public class Main {
    private static final int DEFAULT_MONTHS = 10;

    private static final String[] INITIAL_DATA = {
        "Côtes du Rhône;5;20",
        "Pomerol de garde;8;25",
        "Cuvée du Fondateur;0;100",
        "Cuvée du Fondateur;-1;100",
        "Primeur Pauillac;15;20",
        "Primeur Pauillac;10;49",
        "Primeur Pauillac;5;49",
        "Beaujolais nouveau;2;7",
        "Muscadet;0;6",
        "Entamé Chablis;3;6",
        "Bio Chinon;4;10",
        "Vin de pays;0;3"
    };

    public static void main(String[] args) {
        int months = args.length > 0 ? Integer.parseInt(args[0]) : DEFAULT_MONTHS;
        Cellar cellar = new Cellar(initialBottles());
        for (int month = 0; month <= months; month++) {
            System.out.println("Mois " + month);
            for (Bottle bottle : cellar.bottles) {
                System.out.println("  " + bottle);
            }
            cellar.ageOneMonth();
        }
    }

    private static Bottle[] initialBottles() {
        Bottle[] bottles = new Bottle[INITIAL_DATA.length];
        for (int i = 0; i < bottles.length; i++) {
            String[] fields = INITIAL_DATA[i].split(";");
            bottles[i] = new Bottle(fields[0], Integer.parseInt(fields[1]), Integer.parseInt(fields[2]));
        }
        return bottles;
    }
}
