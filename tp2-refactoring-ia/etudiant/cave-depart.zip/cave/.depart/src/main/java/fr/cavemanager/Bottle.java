package fr.cavemanager;

public class Bottle {
    public String name;
    public int monthsLeft;
    public int rating;

    public Bottle(String name, int monthsLeft, int rating) {
        this.name = name;
        this.monthsLeft = monthsLeft;
        this.rating = rating;
    }

    @Override
    public String toString() {
        return name + ", " + monthsLeft + ", " + rating;
    }
}
